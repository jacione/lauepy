"""
HEXOMAP is a Cuda-based (realized through pycuda) near-filed
high-energy X-ray diffraction (NF-HEDM) reconstruction
toolkit that provides 3D microstructure reconstructeds
with high fadelity and efficiency.
"""

